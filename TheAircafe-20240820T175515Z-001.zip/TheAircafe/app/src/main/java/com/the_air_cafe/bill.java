package com.the_air_cafe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class bill extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill);
    }
}